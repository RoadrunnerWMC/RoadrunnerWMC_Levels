This level supports all US, EU, and JP versions of the game.

PLEASE NOTE: This level is best played with a real Wii Remote.

ALSO NOTE: This level has a secret exit.


Riivolution Instructions
* Copy the contest_level and riivolution folders to SD card or USB root
* Launch like any other Riivolution patch (select the "Contest Level" patch)
* The level can be found in the 1-1 slot

Dolphin Instructions
* Copy the contest_level folder over an extracted NSMBW (not Newer) ISO
* Launch main.dol in Dolphin
* Pause, go to Tools -> Cheats Manager, and add the contents of ar_code_for_dolphin.txt as a new AR code
* (IMPORTANT) Stop the game, and relaunch it
* The level can be found in the 1-1 slot

Dolphin Troubleshooting
* If you forgot to relaunch the game after adding the cheat code, do that
* Make sure "Enable Cheats" is checked in Configuration
* Make sure no other AR codes or Gecko codes are enabled
